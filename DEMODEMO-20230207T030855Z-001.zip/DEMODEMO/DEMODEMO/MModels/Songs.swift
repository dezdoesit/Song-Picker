//
//  Songs.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import Foundation

struct Song: Hashable, Identifiable{
    let id = UUID()
    var name: String
    var category: Category
    var description: String
    var Image: String? = nil
    
}

extension Song {
    static var mock: Song{
        DataModel.shared.songMock
    }
}
