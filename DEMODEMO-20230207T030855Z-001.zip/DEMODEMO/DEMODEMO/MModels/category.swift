//
//  category.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import SwiftUI
enum Category: Int, Hashable, CaseIterable, Identifiable, Codable{
    case calm, favorites, classic
    var id: Int{rawValue}
    
    var localizedName: LocalizedStringKey{
        switch self{
        case .calm:
            return "Calm"
        case .favorites:
            return "Favorites"
        case .classic:
            return "Classics"
        }
    }
}
