//
//  NavigationModel.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/20/22.
//

import Foundation
import Combine

final class NavigationModel: ObservableObject{
    @Published var songPath: [Song]
    
    init(songPath: [Song] = []) {
        self.songPath = songPath
    }
    
    var selectedSong: Song? {
        get {songPath.first}
        set {songPath = [newValue].compactMap{$0}}
    }
}
