//
//  DataModel.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import Foundation

class DataModel: ObservableObject{
    @Published var Songs: [Song] = []
    
    static let shared: DataModel = DataModel()
    
    private init(){
        Songs = builtIntSongs
    }
    
    func Songs(in category: Category?) -> [Song]{
        Songs
            .filter{$0.category == category}
            .sorted{$0.name < $1.name}
            
    }
    
    func relatedSongs(relatedTo song : Song, songPath: [Song]) -> [Song]{
        var relatedSongsArray = Songs
            .filter{$0.category == song.category}
            .sorted{$0.name < $1.name}
        if let index = relatedSongsArray.firstIndex(of: song){
            relatedSongsArray.remove(at: index)
        }
        if songPath.count > 1{
            for songInsidePath in songPath{
                if let index = relatedSongsArray.firstIndex(of: songInsidePath){
                    relatedSongsArray.remove(at: index)
                }
            }
            
        }
        return relatedSongsArray
    }
    
    var songMock: Song{
        Songs.first!
    }
}

private let builtIntSongs: [Song] = {
    var songs = [
        Song(name: "LuvSic", category: .calm, description: "By: Shing02", Image: "LuvSic"),
        Song(name: "Feather", category: .calm, description: "By: Nujabes", Image: "Feather"),
        Song(name: "Can't Wait", category: .calm, description: "By: Chon", Image: "Chon"),
        Song(name: "Rain", category: .classic, description: "By: SWV", Image: "Rain"),
        Song(name: "I Gave You Power", category: .classic, description: "By: Nas", Image: "Nas"),
        Song(name: "The Unseen", category: .classic, description: "By: Quasimoto", Image: "Quas"),
        Song(name: "Blessa", category: .favorites, description: "By: Toro y Moi", Image: "Blessa"),
        Song(name: "Never Catch Me", category: .favorites, description: "By: Flying Lotus, Kendrick Lamar", Image: "Lotus"),
        Song(name: "Rental", category: .favorites, description: "By: Juice Wrld", Image: "Juice")
    
    
    ]
    
    return Array(songs)
}()
