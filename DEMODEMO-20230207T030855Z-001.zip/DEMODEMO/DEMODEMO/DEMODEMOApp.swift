//
//  DEMODEMOApp.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import SwiftUI

@main
struct DEMODEMOApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
