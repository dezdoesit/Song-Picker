//
//  NavigationView.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import SwiftUI

struct NavigationView: View {
    @EnvironmentObject private var navigationModel: NavigationModel
    var dataModel = DataModel.shared
    
    var body: some View {
        NavigationStack(path: $navigationModel.songPath){
            List(Category.allCases){category in Section{
                ForEach(dataModel.Songs(in:category)){song in NavigationLink(song.name, value: song)
                }
                
            } header: {
                Text(category.localizedName)
                }
            }
            .navigationTitle("Songs")
            .navigationDestination(for: Song.self){song in
                ScrollView{
                    SongDetailView(song: song){relatedSong in NavigationLink(value: relatedSong){
                        VStack{
                            if (relatedSong.Image != nil){
                                Image(relatedSong.Image!)
                                    .resizable()
                                    .frame(width: 300, height: 180)
                                    .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Text(relatedSong.name)
                                Text(relatedSong.description)
                                    .foregroundColor(.gray)
                            }
                        }
                        .foregroundColor(.blue)
                        
                    }
                    .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

struct NavigationView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView().environmentObject(NavigationModel())
    }
}
