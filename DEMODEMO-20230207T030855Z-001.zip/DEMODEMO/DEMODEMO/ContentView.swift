//
//  ContentView.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import SwiftUI


struct ContentView: View {
    
    @StateObject private var navigationModel = NavigationModel()
    
    var body: some View {
        NavigationView().environmentObject(navigationModel)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
