//
//  SongDetailView.swift
//  DEMODEMO
//
//  Created by Dezmond Blair on 12/19/22.
//

import SwiftUI

struct SongDetailView<Link: View>: View {
    @EnvironmentObject private var navigationModel:NavigationModel
    var song: Song?
    var relatedLink: (Song) -> Link
    
    var body: some View {
        if let song = song{
            VStack{
                if song.Image != nil{
                    Image(song.Image!).aspectRatio( contentMode: .fill)
                }
                Text(song.description)
                    .font(.title2)
                    .foregroundColor(.gray)
                
                Text("Related Songs")
                    .font(.title2)
                
                Context(song: song, relatedLink: relatedLink)
            }
            .navigationTitle(song.name)
            .toolbar{
                Button(action: {
                    navigationModel.songPath.removeAll()
                }, label: {
                    Label("Remove all path", systemImage: "trash.fill")
                })
            }
        }
        else{
            Text("Select Song")
                .navigationTitle("Choose Song")
        }
    }
}

private struct Context<Link: View> : View{
    @EnvironmentObject private var navigationModel: NavigationModel
    var song: Song
    var dataModel = DataModel.shared
    var relatedLink: (Song) -> Link
    
    var body: some View{
        ScrollView(.horizontal){
            HStack(spacing:20){
                let relatedSongs = dataModel.relatedSongs(relatedTo: song, songPath: navigationModel.songPath)
                ForEach(relatedSongs){songItem in relatedLink(songItem)
                    
                }
            }
            .padding(.leading,50)
            .padding(.trailing, 50)
            .padding(.bottom, 10)
        }
    }
}
    struct SongDetailView_Previews: PreviewProvider {
        static var previews: some View {
            Group{
                SongDetailView(song: .mock, relatedLink: link).environmentObject(NavigationModel())
                SongDetailView(song: nil, relatedLink: link)
            }
            
        }
        
        static func link(song: Song) -> some View{
            EmptyView()
    }
}
